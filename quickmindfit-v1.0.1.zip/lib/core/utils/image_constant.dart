class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Profile images
  static String imgScreenshot2023 = '$imagePath/img_screenshot_2023.png';

  static String imgEllipse2 = '$imagePath/img_ellipse_2.png';

  static String imgScreenshot202331x35 =
      '$imagePath/img_screenshot_2023_31x35.png';

  static String imgImageRemovebgPreview =
      '$imagePath/img_image_removebg_preview.png';

  static String imgImageRemovebgPreview42x40 =
      '$imagePath/img_image_removebg_preview_42x40.png';

  static String imgImageRemovebgPreview42x41 =
      '$imagePath/img_image_removebg_preview_42x41.png';

  // Settings images
  static String imgEllipse1 = '$imagePath/img_ellipse_1.png';

  // Search images
  static String imgProfileIcon = '$imagePath/img_profile_icon.png';

  static String imgSearch = '$imagePath/img_search.png';

  // Chatbot images
  static String imgHelp = '$imagePath/img_help.png';

  static String imgFacebookLike = '$imagePath/img_facebook_like.png';

  static String imgEllipsis = '$imagePath/img_ellipsis.png';

  static String imgPaperPlane = '$imagePath/img_paper_plane.png';

  // About Us images
  static String imgIstockphoto149 = '$imagePath/img_istockphoto_149.png';

  static String imgMailAddIcon2 = '$imagePath/img_mail_add_icon_2.png';

  static String imgInstagramIcon4 = '$imagePath/img_instagram_icon_4.png';

  static String imgLogoOfTwitter = '$imagePath/img_logo_of_twitter.png';

  static String imgFacebookIcon5 = '$imagePath/img_facebook_icon_5.png';

  // Tech Support images
  static String imgTransparentTec = '$imagePath/img_transparent_tec.png';

  // Notification images
  static String imgNotif1 = '$imagePath/img_notif_1.png';

  // Common images
  static String imgHome2 = '$imagePath/img_home_2.png';

  static String imgSearch2 = '$imagePath/img_search_2.png';

  static String imgRobot2 = '$imagePath/img_robot2.png';

  static String imgProfile2 = '$imagePath/img_profile_2.png';

  static String imgRectangle14 = '$imagePath/img_rectangle_14.png';

  static String imgGroup38 = '$imagePath/img_group_38.png';

  static String imgHeartWithPulse = '$imagePath/img_heart_with_pulse.png';

  static String imgBarbell = '$imagePath/img_barbell.png';

  static String imgStopwatch = '$imagePath/img_stopwatch.png';

  static String imgYoga = '$imagePath/img_yoga.png';

  static String img21 = '$imagePath/img_2_1.png';

  static String img23 = '$imagePath/img_2_3.png';

  static String imgUserIcon = '$imagePath/img_user_icon.png';

  static String imgBell = '$imagePath/img_bell.png';

  static String imgHome = '$imagePath/img_home.png';

  static String imgGoBack = '$imagePath/img_go_back.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
