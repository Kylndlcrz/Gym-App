import 'package:quickmindfit/core/app_export.dart';

class ApiClient {}
