import 'bloc/profile_bloc.dart';
import 'models/profile_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';
import 'package:quickmindfit/presentation/home_container_page/home_container_page.dart';
import 'package:quickmindfit/widgets/custom_bottom_bar.dart';

class ProfileScreen extends StatelessWidget {
  ProfileScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<ProfileBloc>(
      create: (context) => ProfileBloc(ProfileState(
        profileModelObj: ProfileModel(),
      ))
        ..add(ProfileInitialEvent()),
      child: ProfileScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ProfileBloc, ProfileState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: double.maxFinite,
              child: Column(
                children: [
                  SizedBox(height: 46.v),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: EdgeInsets.only(bottom: 5.v),
                        child: Column(
                          children: [
                            _buildScreenshotRow(context),
                            SizedBox(height: 11.v),
                            Text(
                              "lbl_jarius_rlan".tr,
                              style: TextStyle(
                                color: theme.colorScheme.onPrimaryContainer
                                    .withOpacity(1),
                                fontSize: 24.fSize,
                                fontFamily: 'Inria Sans',
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 9.v),
                            Text(
                              "lbl_jr_fitness".tr,
                              style: TextStyle(
                                color: theme.colorScheme.onPrimaryContainer
                                    .withOpacity(1),
                                fontSize: 16.fSize,
                                fontFamily: 'Inria Sans',
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 29.v),
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: 77.h),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    width: 66.h,
                                    margin: EdgeInsets.only(
                                      top: 8.v,
                                      bottom: 3.v,
                                    ),
                                    child: Text(
                                      "lbl_0_followers".tr,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: theme
                                            .colorScheme.onPrimaryContainer
                                            .withOpacity(1),
                                        fontSize: 16.fSize,
                                        fontFamily: 'Inria Sans',
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                  Spacer(
                                    flex: 50,
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(bottom: 6.v),
                                    child: Text(
                                      "lbl".tr,
                                      style: TextStyle(
                                        color: theme.colorScheme.onPrimary,
                                        fontSize: 36.fSize,
                                        fontFamily: 'Inria Sans',
                                        fontWeight: FontWeight.w300,
                                      ),
                                    ),
                                  ),
                                  Spacer(
                                    flex: 50,
                                  ),
                                  Container(
                                    width: 67.h,
                                    margin: EdgeInsets.only(top: 8.v),
                                    child: Text(
                                      "lbl_0_following".tr,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: theme
                                            .colorScheme.onPrimaryContainer
                                            .withOpacity(1),
                                        fontSize: 16.fSize,
                                        fontFamily: 'Inria Sans',
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 34.v),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: EdgeInsets.only(left: 29.h),
                                child: Text(
                                  "lbl_my_profile".tr,
                                  style: TextStyle(
                                    color: theme.colorScheme.onPrimaryContainer
                                        .withOpacity(1),
                                    fontSize: 16.fSize,
                                    fontFamily: 'Inria Sans',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 15.v),
                            _buildWorkoutsTotalRow(context),
                            SizedBox(height: 29.v),
                            _buildPersonalInfoRow(context),
                            SizedBox(height: 18.v),
                            _buildDescriptionRow(context),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: _buildBottomBar(context),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildScreenshotRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 29.h,
        right: 23.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgScreenshot2023,
            height: 25.v,
            width: 29.h,
            margin: EdgeInsets.only(
              top: 23.v,
              bottom: 22.v,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgEllipse2,
            height: 70.adaptSize,
            width: 70.adaptSize,
            radius: BorderRadius.circular(
              35.h,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgScreenshot202331x35,
            height: 31.v,
            width: 35.h,
            margin: EdgeInsets.only(
              top: 23.v,
              bottom: 15.v,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildWorkoutsTotalRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 25.h,
        right: 28.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: 18.v),
            child: Column(
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgImageRemovebgPreview,
                  height: 42.v,
                  width: 35.h,
                ),
                SizedBox(height: 16.v),
                Text(
                  "lbl_workouts_total".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 15.fSize,
                    fontFamily: 'Inria Sans',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 23.h,
              bottom: 18.v,
            ),
            child: Column(
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgImageRemovebgPreview42x40,
                  height: 42.v,
                  width: 40.h,
                ),
                SizedBox(height: 16.v),
                Text(
                  "lbl_calories_burnt".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 15.fSize,
                    fontFamily: 'Inria Sans',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Spacer(),
          Column(
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgImageRemovebgPreview42x41,
                height: 42.v,
                width: 41.h,
              ),
              SizedBox(height: 16.v),
              SizedBox(
                width: 60.h,
                child: Text(
                  "msg_rewards_collected".tr,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 15.fSize,
                    fontFamily: 'Inria Sans',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildPersonalInfoRow(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 31.h,
              vertical: 25.v,
            ),
            decoration: AppDecoration.fillOnPrimary,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 2.v),
                Text(
                  "lbl_personal_info".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 20.fSize,
                    fontFamily: 'Inria Sans',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 53.h,
              vertical: 23.v,
            ),
            decoration: AppDecoration.fillOnPrimary,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(height: 6.v),
                Text(
                  "lbl_family".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 20.fSize,
                    fontFamily: 'Inria Sans',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNameOfFamilyMemberColumn(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 42.v,
      ),
      decoration: AppDecoration.fillOnPrimary,
      child: SizedBox(
        width: 137.h,
        child: Text(
          "msg_name_of_family".tr,
          maxLines: 4,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
            fontSize: 20.fSize,
            fontFamily: 'Inria Sans',
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildDescriptionRow(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 22.h,
              vertical: 42.v,
            ),
            decoration: AppDecoration.fillOnPrimary,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 35.v),
                SizedBox(
                  width: 101.h,
                  child: Text(
                    "msg_birthdate_ag".tr,
                    maxLines: 13,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color:
                          theme.colorScheme.onPrimaryContainer.withOpacity(1),
                      fontSize: 20.fSize,
                      fontFamily: 'Inria Sans',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
          _buildNameOfFamilyMemberColumn(context),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeContainerPage;
      case BottomBarEnum.Search2:
        return "/";
      case BottomBarEnum.Robot2:
        return "/";
      case BottomBarEnum.Profile2:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.homeContainerPage:
        return HomeContainerPage();
      default:
        return DefaultWidget();
    }
  }
}
