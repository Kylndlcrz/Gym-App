import 'bloc/settings_bloc.dart';
import 'models/settings_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';
import 'package:quickmindfit/presentation/home_container_page/home_container_page.dart';
import 'package:quickmindfit/widgets/custom_bottom_bar.dart';
import 'package:quickmindfit/widgets/custom_outlined_button.dart';

// ignore_for_file: must_be_immutable
class SettingsScreen extends StatelessWidget {
  SettingsScreen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<SettingsBloc>(
        create: (context) =>
            SettingsBloc(SettingsState(settingsModelObj: SettingsModel()))
              ..add(SettingsInitialEvent()),
        child: SettingsScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsBloc, SettingsState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              body: Container(
                  width: double.maxFinite,
                  padding:
                      EdgeInsets.symmetric(horizontal: 25.h, vertical: 38.v),
                  child: Column(children: [
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text("lbl_settings".tr,
                            style: TextStyle(
                                color: appTheme.red50,
                                fontSize: 32.fSize,
                                fontFamily: 'Inria Sans',
                                fontWeight: FontWeight.w700))),
                    SizedBox(height: 28.v),
                    _buildProfileDetails(context),
                    SizedBox(height: 28.v),
                    _buildNotifications(context,
                        notificationText: "lbl_language".tr,
                        arrowText: "lbl2".tr, onTapArrowText: () {
                      onTapTxtArrowText(context);
                    }),
                    _buildNotifications(context,
                        notificationText: "lbl_notifications".tr,
                        arrowText: "lbl2".tr, onTapArrowText: () {
                      onTapTxtArrowText1(context);
                    }),
                    _buildNotifications(context,
                        notificationText: "lbl_about_us".tr,
                        arrowText: "lbl2".tr, onTapArrowText: () {
                      onTapTxtArrowText2(context);
                    }),
                    _buildNotifications(context,
                        notificationText: "lbl_tech_support".tr,
                        arrowText: "lbl2".tr, onTapArrowText: () {
                      onTapTxtArrowText3(context);
                    }),
                    SizedBox(height: 29.v),
                    CustomOutlinedButton(text: "lbl_sign_out".tr),
                    SizedBox(height: 5.v)
                  ])),
              bottomNavigationBar: _buildBottomBar(context)));
    });
  }

  /// Section Widget
  Widget _buildProfileDetails(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(11.h),
        decoration: AppDecoration.outlineSecondaryContainer
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder20),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CustomImageView(
              imagePath: ImageConstant.imgEllipse1,
              height: 49.v,
              width: 51.h,
              radius: BorderRadius.circular(25.h),
              margin: EdgeInsets.only(bottom: 2.v)),
          Padding(
              padding: EdgeInsets.only(left: 14.h, top: 4.v, bottom: 8.v),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("lbl_profile_details".tr,
                        style: TextStyle(
                            color: theme.colorScheme.onPrimaryContainer
                                .withOpacity(1),
                            fontSize: 16.fSize,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w700)),
                    SizedBox(height: 4.v),
                    Text("lbl_edit_profile".tr,
                        style: TextStyle(
                            color: theme.colorScheme.onPrimaryContainer
                                .withOpacity(1),
                            fontSize: 10.fSize,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w500))
                  ])),
          Spacer(),
          Padding(
              padding: EdgeInsets.only(top: 2.v, right: 14.h, bottom: 4.v),
              child: Text("lbl2".tr,
                  style: TextStyle(
                      color:
                          theme.colorScheme.onPrimaryContainer.withOpacity(1),
                      fontSize: 36.fSize,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w400)))
        ]));
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));
    });
  }

  /// Common widget
  Widget _buildNotifications(
    BuildContext context, {
    required String notificationText,
    required String arrowText,
    Function? onTapArrowText,
  }) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 15.h, vertical: 13.v),
        decoration: AppDecoration.outlineSecondaryContainer2,
        child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                  padding: EdgeInsets.only(top: 11.v, bottom: 13.v),
                  child: Text(notificationText,
                      style: TextStyle(
                          color: theme.colorScheme.onPrimaryContainer
                              .withOpacity(1),
                          fontSize: 20.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600))),
              GestureDetector(onTap: () {
                onTapArrowText!.call();
              }),
              Padding(
                  padding: EdgeInsets.only(top: 6.v, right: 11.h),
                  child: Text(arrowText,
                      style: TextStyle(
                          color: theme.colorScheme.onPrimaryContainer
                              .withOpacity(1),
                          fontSize: 36.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400)))
            ]));
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeContainerPage;
      case BottomBarEnum.Search2:
        return "/";
      case BottomBarEnum.Robot2:
        return "/";
      case BottomBarEnum.Profile2:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.homeContainerPage:
        return HomeContainerPage();
      default:
        return DefaultWidget();
    }
  }

  /// Navigates to the selectLanguageScreen when the action is triggered.
  onTapTxtArrowText(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.selectLanguageScreen,
    );
  }

  /// Navigates to the notificationScreen when the action is triggered.
  onTapTxtArrowText1(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.notificationScreen,
    );
  }

  /// Navigates to the aboutUsScreen when the action is triggered.
  onTapTxtArrowText2(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.aboutUsScreen,
    );
  }

  /// Navigates to the techSupportScreen when the action is triggered.
  onTapTxtArrowText3(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.techSupportScreen,
    );
  }
}
