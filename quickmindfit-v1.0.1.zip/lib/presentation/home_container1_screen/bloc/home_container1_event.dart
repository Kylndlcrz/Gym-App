// ignore_for_file: must_be_immutable

part of 'home_container1_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///HomeContainer1 widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class HomeContainer1Event extends Equatable {}

/// Event that is dispatched when the HomeContainer1 widget is first created.
class HomeContainer1InitialEvent extends HomeContainer1Event {
  @override
  List<Object?> get props => [];
}
