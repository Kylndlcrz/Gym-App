import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:quickmindfit/presentation/home_container1_screen/models/home_container1_model.dart';
part 'home_container1_event.dart';
part 'home_container1_state.dart';

/// A bloc that manages the state of a HomeContainer1 according to the event that is dispatched to it.
class HomeContainer1Bloc
    extends Bloc<HomeContainer1Event, HomeContainer1State> {
  HomeContainer1Bloc(HomeContainer1State initialState) : super(initialState) {
    on<HomeContainer1InitialEvent>(_onInitialize);
  }

  _onInitialize(
    HomeContainer1InitialEvent event,
    Emitter<HomeContainer1State> emit,
  ) async {
    Future.delayed(const Duration(milliseconds: 3000), () {
      NavigatorService.popAndPushNamed(
        AppRoutes.searchScreen,
      );
    });
  }
}
