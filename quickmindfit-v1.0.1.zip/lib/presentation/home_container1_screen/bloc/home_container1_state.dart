// ignore_for_file: must_be_immutable

part of 'home_container1_bloc.dart';

/// Represents the state of HomeContainer1 in the application.
class HomeContainer1State extends Equatable {
  HomeContainer1State({this.homeContainer1ModelObj});

  HomeContainer1Model? homeContainer1ModelObj;

  @override
  List<Object?> get props => [
        homeContainer1ModelObj,
      ];
  HomeContainer1State copyWith({HomeContainer1Model? homeContainer1ModelObj}) {
    return HomeContainer1State(
      homeContainer1ModelObj:
          homeContainer1ModelObj ?? this.homeContainer1ModelObj,
    );
  }
}
