import 'bloc/about_us_bloc.dart';
import 'models/about_us_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';
import 'package:quickmindfit/presentation/home_container_page/home_container_page.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_title.dart';
import 'package:quickmindfit/widgets/app_bar/custom_app_bar.dart';
import 'package:quickmindfit/widgets/custom_bottom_bar.dart';

class AboutUsScreen extends StatelessWidget {
  AboutUsScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<AboutUsBloc>(
      create: (context) => AboutUsBloc(AboutUsState(
        aboutUsModelObj: AboutUsModel(),
      ))
        ..add(AboutUsInitialEvent()),
      child: AboutUsScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AboutUsBloc, AboutUsState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            appBar: _buildAppBar(context),
            body: Container(
              width: 375.h,
              padding: EdgeInsets.symmetric(
                horizontal: 19.h,
                vertical: 11.v,
              ),
              child: Column(
                children: [
                  Container(
                    width: 309.h,
                    margin: EdgeInsets.only(
                      left: 15.h,
                      right: 13.h,
                    ),
                    child: Text(
                      "msg_you_can_get_in_touch".tr,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color:
                            theme.colorScheme.onPrimaryContainer.withOpacity(1),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  SizedBox(height: 20.v),
                  _buildCustomerSupport(context),
                  SizedBox(height: 20.v),
                  _buildSocialMediaPlatforms(context),
                  SizedBox(height: 5.v),
                ],
              ),
            ),
            bottomNavigationBar: _buildBottomBar(context),
          ),
        );
      },
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 88.v,
      title: Padding(
        padding: EdgeInsets.only(left: 34.h),
        child: Row(
          children: [
            AppbarTitle(
              text: "lbl3".tr,
            ),
            AppbarTitle(
              text: "lbl_contact_us".tr,
              margin: EdgeInsets.only(left: 23.h),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildCustomerSupport(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 1.h),
      padding: EdgeInsets.symmetric(
        horizontal: 14.h,
        vertical: 13.v,
      ),
      decoration: AppDecoration.fillOnPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder5,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "msg_customer_support".tr,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 15.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          SizedBox(height: 8.v),
          Container(
            margin: EdgeInsets.only(right: 9.h),
            padding: EdgeInsets.symmetric(
              horizontal: 11.h,
              vertical: 1.v,
            ),
            decoration: AppDecoration.outlineSecondaryContainer4.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder20,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgIstockphoto149,
                  height: 29.v,
                  width: 33.h,
                  margin: EdgeInsets.only(
                    top: 4.v,
                    bottom: 3.v,
                  ),
                ),
                Container(
                  width: 119.h,
                  margin: EdgeInsets.only(left: 41.h),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "lbl_contact_number".tr,
                          style: theme.textTheme.titleSmall,
                        ),
                        TextSpan(
                          text: "lbl_09067720310".tr,
                          style: theme.textTheme.bodySmall,
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 10.v),
          Container(
            margin: EdgeInsets.only(right: 9.h),
            padding: EdgeInsets.symmetric(horizontal: 13.h),
            decoration: AppDecoration.outlineSecondaryContainer4.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder20,
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.max,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgMailAddIcon2,
                  height: 30.adaptSize,
                  width: 30.adaptSize,
                  margin: EdgeInsets.only(
                    top: 9.v,
                    bottom: 3.v,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSocialMediaPlatforms(BuildContext context) {
    return Container(
      width: 336.h,
      padding: EdgeInsets.symmetric(
        horizontal: 13.h,
        vertical: 9.v,
      ),
      decoration: AppDecoration.fillOnPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder5,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "msg_social_media_platforms".tr,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 15.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          SizedBox(height: 9.v),
          _buildLogoOfTwitter(
            context,
            logoImage: ImageConstant.imgInstagramIcon4,
            profileText: "msg_instagram_quick_mindfit".tr,
          ),
          SizedBox(height: 10.v),
          _buildLogoOfTwitter(
            context,
            logoImage: ImageConstant.imgLogoOfTwitter,
            profileText: "msg_twitter_qck_mndft".tr,
          ),
          SizedBox(height: 8.v),
          _buildLogoOfTwitter(
            context,
            logoImage: ImageConstant.imgFacebookIcon5,
            profileText: "msg_facebook_quick_mindfit".tr,
          ),
          SizedBox(height: 4.v),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  /// Common widget
  Widget _buildLogoOfTwitter(
    BuildContext context, {
    required String logoImage,
    required String profileText,
  }) {
    return SizedBox(
      height: 42.v,
      width: 299.h,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Align(
            alignment: Alignment.center,
            child: Container(
              height: 42.v,
              width: 299.h,
              padding: EdgeInsets.symmetric(
                horizontal: 15.h,
                vertical: 6.v,
              ),
              decoration: AppDecoration.outlineSecondaryContainer4.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder20,
              ),
              child: CustomImageView(
                imagePath: logoImage,
                height: 24.v,
                width: 30.h,
                alignment: Alignment.topLeft,
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SizedBox(
              width: 51.h,
              child: RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "lbl_twitter".tr,
                      style: theme.textTheme.titleSmall,
                    ),
                    TextSpan(
                      text: "lbl_qck_mndft".tr,
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeContainerPage;
      case BottomBarEnum.Search2:
        return "/";
      case BottomBarEnum.Robot2:
        return "/";
      case BottomBarEnum.Profile2:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.homeContainerPage:
        return HomeContainerPage();
      default:
        return DefaultWidget();
    }
  }
}
