// ignore_for_file: must_be_immutable

part of 'select_language_bloc.dart';

/// Represents the state of SelectLanguage in the application.
class SelectLanguageState extends Equatable {
  SelectLanguageState({
    this.searchController,
    this.selectLanguageModelObj,
  });

  TextEditingController? searchController;

  SelectLanguageModel? selectLanguageModelObj;

  @override
  List<Object?> get props => [
        searchController,
        selectLanguageModelObj,
      ];
  SelectLanguageState copyWith({
    TextEditingController? searchController,
    SelectLanguageModel? selectLanguageModelObj,
  }) {
    return SelectLanguageState(
      searchController: searchController ?? this.searchController,
      selectLanguageModelObj:
          selectLanguageModelObj ?? this.selectLanguageModelObj,
    );
  }
}
