import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:quickmindfit/presentation/select_language_screen/models/select_language_model.dart';
part 'select_language_event.dart';
part 'select_language_state.dart';

/// A bloc that manages the state of a SelectLanguage according to the event that is dispatched to it.
class SelectLanguageBloc
    extends Bloc<SelectLanguageEvent, SelectLanguageState> {
  SelectLanguageBloc(SelectLanguageState initialState) : super(initialState) {
    on<SelectLanguageInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SelectLanguageInitialEvent event,
    Emitter<SelectLanguageState> emit,
  ) async {
    emit(state.copyWith(
      searchController: TextEditingController(),
    ));
  }
}
