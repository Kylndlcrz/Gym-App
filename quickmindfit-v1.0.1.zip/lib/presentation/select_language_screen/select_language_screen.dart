import 'bloc/select_language_bloc.dart';
import 'models/select_language_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';
import 'package:quickmindfit/widgets/custom_outlined_button.dart';
import 'package:quickmindfit/widgets/custom_search_view.dart';

class SelectLanguageScreen extends StatelessWidget {
  const SelectLanguageScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<SelectLanguageBloc>(
      create: (context) => SelectLanguageBloc(SelectLanguageState(
        selectLanguageModelObj: SelectLanguageModel(),
      ))
        ..add(SelectLanguageInitialEvent()),
      child: SelectLanguageScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 39.v),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 10.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: 13.h,
                      right: 13.h,
                      bottom: 5.v,
                    ),
                    child: Column(
                      children: [
                        BlocSelector<SelectLanguageBloc, SelectLanguageState,
                            TextEditingController?>(
                          selector: (state) => state.searchController,
                          builder: (context, searchController) {
                            return CustomSearchView(
                              controller: searchController,
                              hintText: "lbl_search".tr,
                              borderDecoration:
                                  SearchViewStyleHelper.fillOnPrimaryTL28,
                            );
                          },
                        ),
                        SizedBox(height: 41.v),
                        _buildLanguageOptions(context),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildContinueButton(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildLanguageOptions(BuildContext context) {
    return Container(
      width: 318.h,
      margin: EdgeInsets.only(
        left: 3.h,
        right: 12.h,
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 21.h,
        vertical: 24.v,
      ),
      decoration: AppDecoration.fillOnPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder30,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 3.h),
            child: Text(
              "lbl_english".tr,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 20.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          SizedBox(height: 49.v),
          Padding(
            padding: EdgeInsets.only(left: 3.h),
            child: Text(
              "lbl_filipino".tr,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 20.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          SizedBox(height: 51.v),
          Padding(
            padding: EdgeInsets.only(left: 3.h),
            child: Text(
              "lbl_japanese".tr,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 20.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          SizedBox(height: 49.v),
          Text(
            "lbl_chinese".tr,
            style: TextStyle(
              color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
              fontSize: 20.fSize,
              fontFamily: 'Inter',
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 54.v),
          Padding(
            padding: EdgeInsets.only(left: 1.h),
            child: Text(
              "lbl_korean".tr,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 20.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          SizedBox(height: 49.v),
          Text(
            "lbl_arabic".tr,
            style: TextStyle(
              color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
              fontSize: 20.fSize,
              fontFamily: 'Inter',
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildContinueButton(BuildContext context) {
    return CustomOutlinedButton(
      text: "lbl_continue".tr,
      margin: EdgeInsets.only(
        left: 25.h,
        right: 25.h,
        bottom: 39.v,
      ),
      buttonStyle: CustomButtonStyles.outlineSecondaryContainerTL25,
    );
  }
}
