import 'bloc/chatbot_bloc.dart';
import 'models/chatbot_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_trailing_image.dart';
import 'package:quickmindfit/widgets/app_bar/custom_app_bar.dart';
import 'package:quickmindfit/widgets/custom_text_form_field.dart';

class ChatbotScreen extends StatelessWidget {
  const ChatbotScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<ChatbotBloc>(
      create: (context) => ChatbotBloc(ChatbotState(
        chatbotModelObj: ChatbotModel(),
      ))
        ..add(ChatbotInitialEvent()),
      child: ChatbotScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 8.h,
            vertical: 12.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildGroup157(context),
              Spacer(
                flex: 60,
              ),
              _buildPaperPlane(context),
              Spacer(
                flex: 39,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 68.h,
      leading: AppbarLeadingIconbutton(
        imagePath: ImageConstant.imgGoBack,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 14.v,
          bottom: 14.v,
        ),
      ),
      title: SizedBox(
        width: 63.h,
        child: RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: "lbl_flexfit".tr,
                style: CustomTextStyles.titleLargeInriaSansBold,
              ),
              TextSpan(
                text: " ".tr,
                style:
                    CustomTextStyles.titleSmallInriaSansOnPrimaryContainerBold,
              ),
              TextSpan(
                text: "lbl_chatbot".tr,
                style: theme.textTheme.bodyMedium,
              ),
            ],
          ),
          textAlign: TextAlign.left,
        ),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgHelp,
          margin: EdgeInsets.only(
            left: 18.h,
            top: 23.v,
            right: 21.h,
          ),
        ),
        AppbarTrailingImage(
          imagePath: ImageConstant.imgFacebookLike,
          margin: EdgeInsets.fromLTRB(19.h, 23.v, 39.h, 2.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildGroup157(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 3.h,
        right: 44.h,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 57.adaptSize,
            width: 57.adaptSize,
            margin: EdgeInsets.only(bottom: 7.v),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
              borderRadius: BorderRadius.circular(
                28.h,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                left: 7.h,
                top: 3.v,
              ),
              child: BlocSelector<ChatbotBloc, ChatbotState,
                  TextEditingController?>(
                selector: (state) => state.group157Controller,
                builder: (context, group157Controller) {
                  return CustomTextFormField(
                    controller: group157Controller,
                    hintText: "msg_welcome_user_how".tr,
                    borderDecoration: TextFormFieldStyleHelper.fillOnPrimary,
                    fillColor: theme.colorScheme.onPrimary,
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildPaperPlane(BuildContext context) {
    return Row(
      children: [
        CustomImageView(
          imagePath: ImageConstant.imgEllipsis,
          height: 35.v,
          width: 49.h,
          margin: EdgeInsets.only(
            top: 10.v,
            bottom: 8.v,
          ),
        ),
        Expanded(
          child:
              BlocSelector<ChatbotBloc, ChatbotState, TextEditingController?>(
            selector: (state) => state.paperPlaneController,
            builder: (context, paperPlaneController) {
              return CustomTextFormField(
                controller: paperPlaneController,
                textInputAction: TextInputAction.done,
                suffix: Container(
                  margin: EdgeInsets.fromLTRB(30.h, 11.v, 15.h, 10.v),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgPaperPlane,
                    height: 30.v,
                    width: 40.h,
                  ),
                ),
                suffixConstraints: BoxConstraints(
                  maxHeight: 51.v,
                ),
                borderDecoration: TextFormFieldStyleHelper.fillOnPrimaryTL25,
                fillColor: theme.colorScheme.onPrimary,
              );
            },
          ),
        ),
      ],
    );
  }
}
