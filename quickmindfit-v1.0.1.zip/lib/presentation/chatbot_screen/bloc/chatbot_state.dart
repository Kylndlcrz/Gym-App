// ignore_for_file: must_be_immutable

part of 'chatbot_bloc.dart';

/// Represents the state of Chatbot in the application.
class ChatbotState extends Equatable {
  ChatbotState({
    this.group157Controller,
    this.paperPlaneController,
    this.chatbotModelObj,
  });

  TextEditingController? group157Controller;

  TextEditingController? paperPlaneController;

  ChatbotModel? chatbotModelObj;

  @override
  List<Object?> get props => [
        group157Controller,
        paperPlaneController,
        chatbotModelObj,
      ];
  ChatbotState copyWith({
    TextEditingController? group157Controller,
    TextEditingController? paperPlaneController,
    ChatbotModel? chatbotModelObj,
  }) {
    return ChatbotState(
      group157Controller: group157Controller ?? this.group157Controller,
      paperPlaneController: paperPlaneController ?? this.paperPlaneController,
      chatbotModelObj: chatbotModelObj ?? this.chatbotModelObj,
    );
  }
}
