import '../models/userprofile_item_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';

// ignore: must_be_immutable
class UserprofileItemWidget extends StatelessWidget {
  UserprofileItemWidget(
    this.userprofileItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  UserprofileItemModel userprofileItemModelObj;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 75.h,
      child: Padding(
        padding: EdgeInsets.only(bottom: 1.v),
        child: Column(
          children: [
            Container(
              height: 75.adaptSize,
              width: 75.adaptSize,
              padding: EdgeInsets.symmetric(
                horizontal: 14.h,
                vertical: 8.v,
              ),
              decoration: AppDecoration.fillOnPrimary.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder30,
              ),
              child: CustomImageView(
                imagePath: userprofileItemModelObj?.cardiovascImage,
                height: 55.v,
                width: 46.h,
                alignment: Alignment.bottomCenter,
              ),
            ),
            SizedBox(height: 2.v),
            Text(
              userprofileItemModelObj.cardiovascText!,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 12.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
