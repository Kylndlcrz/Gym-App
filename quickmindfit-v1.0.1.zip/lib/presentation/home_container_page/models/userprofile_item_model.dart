import '../../../core/app_export.dart';

/// This class is used in the [userprofile_item_widget] screen.
class UserprofileItemModel {
  UserprofileItemModel({
    this.cardiovascImage,
    this.cardiovascText,
    this.id,
  }) {
    cardiovascImage = cardiovascImage ?? ImageConstant.imgHeartWithPulse;
    cardiovascText = cardiovascText ?? "Cardiovasc";
    id = id ?? "";
  }

  String? cardiovascImage;

  String? cardiovascText;

  String? id;
}
