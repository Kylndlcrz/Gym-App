import '../home_container_page/widgets/userprofile_item_widget.dart';
import 'bloc/home_container_bloc.dart';
import 'models/home_container_model.dart';
import 'models/userprofile_item_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_leading_circleimage.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_title.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_trailing_image.dart';
import 'package:quickmindfit/widgets/app_bar/custom_app_bar.dart';
import 'package:quickmindfit/widgets/custom_icon_button.dart';

// ignore_for_file: must_be_immutable
class HomeContainerPage extends StatelessWidget {
  const HomeContainerPage({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<HomeContainerBloc>(
      create: (context) => HomeContainerBloc(HomeContainerState(
        homeContainerModelObj: HomeContainerModel(),
      ))
        ..add(HomeContainerInitialEvent()),
      child: HomeContainerPage(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.onPrimaryContainer.withOpacity(1),
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            child: SizedBox(
              height: 961.v,
              width: double.maxFinite,
              child: Stack(
                alignment: Alignment.bottomRight,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: SizedBox(
                      height: 961.v,
                      width: double.maxFinite,
                      child: Stack(
                        alignment: Alignment.topCenter,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              height: 961.v,
                              width: double.maxFinite,
                              decoration: BoxDecoration(
                                color: theme.colorScheme.primary.withOpacity(1),
                                borderRadius: BorderRadius.circular(
                                  20.h,
                                ),
                              ),
                            ),
                          ),
                          CustomImageView(
                            imagePath: ImageConstant.imgRectangle14,
                            height: 138.v,
                            width: 310.h,
                            radius: BorderRadius.vertical(
                              top: Radius.circular(30.h),
                            ),
                            alignment: Alignment.topCenter,
                            margin: EdgeInsets.only(top: 383.v),
                          ),
                          _buildYouRenewHereColumn(context),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              height: 53.v,
                              width: 310.h,
                              margin: EdgeInsets.only(bottom: 413.v),
                              decoration: BoxDecoration(
                                color: theme.colorScheme.onPrimary,
                                borderRadius: BorderRadius.circular(
                                  20.h,
                                ),
                              ),
                            ),
                          ),
                          _buildExploreByCategoryColumn(context),
                          _buildQuickAndEffectiveColumn(context),
                        ],
                      ),
                    ),
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.img23,
                    height: 107.v,
                    width: 117.h,
                    radius: BorderRadius.vertical(
                      top: Radius.circular(30.h),
                    ),
                    alignment: Alignment.bottomRight,
                    margin: EdgeInsets.only(bottom: 241.v),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 67.h,
      leading: AppbarLeadingCircleimage(
        imagePath: ImageConstant.imgUserIcon,
        margin: EdgeInsets.only(
          left: 20.h,
          top: 21.v,
          bottom: 21.v,
        ),
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 13.h),
        child: Column(
          children: [
            AppbarTitle(
              text: "lbl_welcome_back".tr,
            ),
            AppbarTitle(
              text: "lbl_user_s_name".tr,
              margin: EdgeInsets.only(right: 29.h),
            ),
          ],
        ),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgBell,
          margin: EdgeInsets.fromLTRB(16.h, 22.v, 16.h, 15.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildYouRenewHereColumn(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Padding(
        padding: EdgeInsets.only(
          left: 20.h,
          top: 98.v,
          right: 10.h,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: EdgeInsets.only(
                left: 7.h,
                right: 13.h,
              ),
              padding: EdgeInsets.symmetric(
                horizontal: 8.h,
                vertical: 18.v,
              ),
              decoration: AppDecoration.fillOnPrimary.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 8.h),
                    child: Text(
                      "msg_you_re_new_here".tr,
                      style: TextStyle(
                        color:
                            theme.colorScheme.onPrimaryContainer.withOpacity(1),
                        fontSize: 16.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  SizedBox(height: 5.v),
                  Padding(
                    padding: EdgeInsets.only(left: 8.h),
                    child: Text(
                      "msg_please_choose_a".tr,
                      style: TextStyle(
                        color:
                            theme.colorScheme.onPrimaryContainer.withOpacity(1),
                        fontSize: 12.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  SizedBox(height: 28.v),
                ],
              ),
            ),
            SizedBox(height: 36.v),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 7.h),
                  child: Text(
                    "msg_discover".tr,
                    style: TextStyle(
                      color:
                          theme.colorScheme.onPrimaryContainer.withOpacity(1),
                      fontSize: 15.fSize,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                SizedBox(height: 13.v),
                Divider(
                  color: theme.colorScheme.onPrimary,
                  endIndent: 13.h,
                ),
              ],
            ),
            SizedBox(height: 18.v),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 47.v,
                  width: 264.h,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.onPrimary,
                    borderRadius: BorderRadius.circular(
                      23.h,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 19.h),
                  child: CustomIconButton(
                    height: 47.adaptSize,
                    width: 47.adaptSize,
                    padding: EdgeInsets.all(2.h),
                    child: CustomImageView(
                      imagePath: ImageConstant.imgGroup38,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 11.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 7.h),
                child: Text(
                  "msg_most_popular_workouts".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 17.fSize,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildExploreByCategoryColumn(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: EdgeInsets.only(
          left: 9.h,
          right: 9.h,
          bottom: 80.v,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "msg_explore_by_category".tr,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 15.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 12.v),
            SizedBox(
              height: 94.v,
              child: BlocSelector<HomeContainerBloc, HomeContainerState,
                  HomeContainerModel?>(
                selector: (state) => state.homeContainerModelObj,
                builder: (context, homeContainerModelObj) {
                  return ListView.separated(
                    scrollDirection: Axis.horizontal,
                    separatorBuilder: (
                      context,
                      index,
                    ) {
                      return SizedBox(
                        width: 14.h,
                      );
                    },
                    itemCount:
                        homeContainerModelObj?.userprofileItemList.length ?? 0,
                    itemBuilder: (context, index) {
                      UserprofileItemModel model =
                          homeContainerModelObj?.userprofileItemList[index] ??
                              UserprofileItemModel();
                      return UserprofileItemWidget(
                        model,
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildQuickAndEffectiveColumn(BuildContext context) {
    return Align(
      alignment: Alignment.bottomRight,
      child: Padding(
        padding: EdgeInsets.only(bottom: 219.v),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "msg_quick_and_effective".tr,
              style: TextStyle(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                fontSize: 16.fSize,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 23.v),
            Padding(
              padding: EdgeInsets.only(left: 12.h),
              child: Row(
                children: [
                  SizedBox(
                    height: 130.v,
                    width: 168.h,
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.img21,
                          height: 110.v,
                          width: 168.h,
                          radius: BorderRadius.vertical(
                            top: Radius.circular(30.h),
                          ),
                          alignment: Alignment.topCenter,
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            height: 53.v,
                            width: 168.h,
                            decoration: BoxDecoration(
                              color: theme.colorScheme.onPrimary,
                              borderRadius: BorderRadius.circular(
                                20.h,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 53.v,
                    width: 168.h,
                    margin: EdgeInsets.only(
                      left: 36.h,
                      top: 77.v,
                    ),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.onPrimary,
                      borderRadius: BorderRadius.circular(
                        20.h,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
