import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/userprofile_item_model.dart';
import 'package:quickmindfit/presentation/home_container_page/models/home_container_model.dart';
part 'home_container_event.dart';
part 'home_container_state.dart';

/// A bloc that manages the state of a HomeContainer according to the event that is dispatched to it.
class HomeContainerBloc extends Bloc<HomeContainerEvent, HomeContainerState> {
  HomeContainerBloc(HomeContainerState initialState) : super(initialState) {
    on<HomeContainerInitialEvent>(_onInitialize);
  }

  _onInitialize(
    HomeContainerInitialEvent event,
    Emitter<HomeContainerState> emit,
  ) async {
    emit(state.copyWith(
        homeContainerModelObj: state.homeContainerModelObj?.copyWith(
      userprofileItemList: fillUserprofileItemList(),
    )));
  }

  List<UserprofileItemModel> fillUserprofileItemList() {
    return [
      UserprofileItemModel(
          cardiovascImage: ImageConstant.imgHeartWithPulse,
          cardiovascText: "Cardiovasc"),
      UserprofileItemModel(
          cardiovascImage: ImageConstant.imgBarbell,
          cardiovascText: "Strength"),
      UserprofileItemModel(
          cardiovascImage: ImageConstant.imgStopwatch,
          cardiovascText: "Endurance"),
      UserprofileItemModel(
          cardiovascImage: ImageConstant.imgYoga, cardiovascText: "Flexibility")
    ];
  }
}
