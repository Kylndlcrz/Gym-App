import 'bloc/tech_support_bloc.dart';
import 'models/tech_support_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_title.dart';
import 'package:quickmindfit/widgets/app_bar/custom_app_bar.dart';
import 'package:quickmindfit/widgets/custom_text_form_field.dart';

class TechSupportScreen extends StatelessWidget {
  const TechSupportScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<TechSupportBloc>(
      create: (context) => TechSupportBloc(TechSupportState(
        techSupportModelObj: TechSupportModel(),
      ))
        ..add(TechSupportInitialEvent()),
      child: TechSupportScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: 375.h,
          child: Container(
            padding: EdgeInsets.all(21.h),
            decoration: AppDecoration.fillPrimary.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder20,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: 87.h,
                      right: 8.h,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(top: 100.v),
                          child: Column(
                            children: [
                              _buildAppBar(context),
                              SizedBox(height: 10.v),
                              CustomImageView(
                                imagePath: ImageConstant.imgTransparentTec,
                                height: 153.v,
                                width: 150.h,
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 37.h,
                            bottom: 151.v,
                          ),
                          child: Text(
                            "lbl4".tr,
                            style: TextStyle(
                              color: theme.colorScheme.onPrimaryContainer
                                  .withOpacity(1),
                              fontSize: 64.fSize,
                              fontFamily: 'Inter',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 25.v),
                Text(
                  "lbl_your_name".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 12.fSize,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 5.v),
                Opacity(
                  opacity: 0.9,
                  child: BlocSelector<TechSupportBloc, TechSupportState,
                      TextEditingController?>(
                    selector: (state) => state.nameController,
                    builder: (context, nameController) {
                      return CustomTextFormField(
                        controller: nameController,
                      );
                    },
                  ),
                ),
                SizedBox(height: 14.v),
                Text(
                  "lbl_e_mail_address2".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 12.fSize,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 5.v),
                Opacity(
                  opacity: 0.9,
                  child: BlocSelector<TechSupportBloc, TechSupportState,
                      TextEditingController?>(
                    selector: (state) => state.emailController,
                    builder: (context, emailController) {
                      return CustomTextFormField(
                        controller: emailController,
                      );
                    },
                  ),
                ),
                SizedBox(height: 12.v),
                Text(
                  "lbl_phone_number".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 12.fSize,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 4.v),
                Opacity(
                  opacity: 0.9,
                  child: BlocSelector<TechSupportBloc, TechSupportState,
                      TextEditingController?>(
                    selector: (state) => state.phoneNumberController,
                    builder: (context, phoneNumberController) {
                      return CustomTextFormField(
                        controller: phoneNumberController,
                        textInputAction: TextInputAction.done,
                      );
                    },
                  ),
                ),
                SizedBox(height: 8.v),
                Text(
                  "msg_problem_description_feedback".tr,
                  style: TextStyle(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                    fontSize: 12.fSize,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 2.v),
                Opacity(
                  opacity: 0.9,
                  child: Container(
                    height: 130.v,
                    width: 333.h,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.onPrimaryContainer
                          .withOpacity(0.67),
                      borderRadius: BorderRadius.circular(
                        25.h,
                      ),
                      border: Border.all(
                        color: theme.colorScheme.secondaryContainer
                            .withOpacity(0.67),
                        width: 1.h,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: theme.colorScheme.primary,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(
                            0,
                            4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 7.v),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 30.v,
      centerTitle: true,
      title: AppbarTitle(
        text: "lbl_tech_support".tr,
      ),
    );
  }
}
