// ignore_for_file: must_be_immutable

part of 'tech_support_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///TechSupport widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class TechSupportEvent extends Equatable {}

/// Event that is dispatched when the TechSupport widget is first created.
class TechSupportInitialEvent extends TechSupportEvent {
  @override
  List<Object?> get props => [];
}
