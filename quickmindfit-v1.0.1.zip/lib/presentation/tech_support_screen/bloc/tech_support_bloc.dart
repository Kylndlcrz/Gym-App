import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:quickmindfit/presentation/tech_support_screen/models/tech_support_model.dart';
part 'tech_support_event.dart';
part 'tech_support_state.dart';

/// A bloc that manages the state of a TechSupport according to the event that is dispatched to it.
class TechSupportBloc extends Bloc<TechSupportEvent, TechSupportState> {
  TechSupportBloc(TechSupportState initialState) : super(initialState) {
    on<TechSupportInitialEvent>(_onInitialize);
  }

  _onInitialize(
    TechSupportInitialEvent event,
    Emitter<TechSupportState> emit,
  ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      emailController: TextEditingController(),
      phoneNumberController: TextEditingController(),
    ));
  }
}
