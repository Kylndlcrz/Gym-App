// ignore_for_file: must_be_immutable

part of 'tech_support_bloc.dart';

/// Represents the state of TechSupport in the application.
class TechSupportState extends Equatable {
  TechSupportState({
    this.nameController,
    this.emailController,
    this.phoneNumberController,
    this.techSupportModelObj,
  });

  TextEditingController? nameController;

  TextEditingController? emailController;

  TextEditingController? phoneNumberController;

  TechSupportModel? techSupportModelObj;

  @override
  List<Object?> get props => [
        nameController,
        emailController,
        phoneNumberController,
        techSupportModelObj,
      ];
  TechSupportState copyWith({
    TextEditingController? nameController,
    TextEditingController? emailController,
    TextEditingController? phoneNumberController,
    TechSupportModel? techSupportModelObj,
  }) {
    return TechSupportState(
      nameController: nameController ?? this.nameController,
      emailController: emailController ?? this.emailController,
      phoneNumberController:
          phoneNumberController ?? this.phoneNumberController,
      techSupportModelObj: techSupportModelObj ?? this.techSupportModelObj,
    );
  }
}
