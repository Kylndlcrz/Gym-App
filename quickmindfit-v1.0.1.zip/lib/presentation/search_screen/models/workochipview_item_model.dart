// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

/// This class is used in the [workochipview_item_widget] screen.
class WorkochipviewItemModel extends Equatable {
  WorkochipviewItemModel({
    this.worko,
    this.isSelected,
  }) {
    worko = worko ?? "Worko";
    isSelected = isSelected ?? false;
  }

  String? worko;

  bool? isSelected;

  WorkochipviewItemModel copyWith({
    String? worko,
    bool? isSelected,
  }) {
    return WorkochipviewItemModel(
      worko: worko ?? this.worko,
      isSelected: isSelected ?? this.isSelected,
    );
  }

  @override
  List<Object?> get props => [worko, isSelected];
}
