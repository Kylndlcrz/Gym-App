import '../models/workochipview_item_model.dart';
import 'package:flutter/material.dart' hide SearchController;
import 'package:quickmindfit/core/app_export.dart';

// ignore: must_be_immutable
class WorkochipviewItemWidget extends StatelessWidget {
  WorkochipviewItemWidget(
    this.workochipviewItemModelObj, {
    Key? key,
    this.onSelectedChipView,
  }) : super(
          key: key,
        );

  WorkochipviewItemModel workochipviewItemModelObj;

  Function(bool)? onSelectedChipView;

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(
        canvasColor: Colors.transparent,
      ),
      child: RawChip(
        padding: EdgeInsets.symmetric(
          horizontal: 11.h,
          vertical: 12.v,
        ),
        showCheckmark: false,
        labelPadding: EdgeInsets.zero,
        label: Text(
          workochipviewItemModelObj.worko!,
          style: TextStyle(
            color: theme.colorScheme.primary.withOpacity(0),
            fontSize: 15.fSize,
            fontFamily: 'Inria Sans',
            fontWeight: FontWeight.w700,
          ),
        ),
        selected: (workochipviewItemModelObj.isSelected ?? false),
        backgroundColor: Colors.transparent,
        selectedColor: Colors.transparent,
        onSelected: (value) {
          onSelectedChipView?.call(value);
        },
      ),
    );
  }
}
