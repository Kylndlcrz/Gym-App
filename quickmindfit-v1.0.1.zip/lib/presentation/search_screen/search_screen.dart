import '../search_screen/widgets/workochipview_item_widget.dart';
import 'bloc/search_bloc.dart';
import 'models/search_model.dart';
import 'models/workochipview_item_model.dart';
import 'package:flutter/material.dart';
import 'package:quickmindfit/core/app_export.dart';
import 'package:quickmindfit/presentation/home_container_page/home_container_page.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:quickmindfit/widgets/app_bar/appbar_trailing_circleimage.dart';
import 'package:quickmindfit/widgets/app_bar/custom_app_bar.dart';
import 'package:quickmindfit/widgets/custom_bottom_bar.dart';
import 'package:quickmindfit/widgets/custom_search_view.dart';

class SearchScreen extends StatelessWidget {
  SearchScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<SearchBloc>(
      create: (context) => SearchBloc(SearchState(
        searchModelObj: SearchModel(),
      ))
        ..add(SearchInitialEvent()),
      child: SearchScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 23.v),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 16.h),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "lbl_hello".tr,
                          style: CustomTextStyles.titleLargeInriaSansBold,
                        ),
                        TextSpan(
                          text: " ".tr,
                          style: theme.textTheme.headlineLarge,
                        ),
                        TextSpan(
                          text: "msg_how_can_we_assist".tr,
                          style: CustomTextStyles
                              .titleSmallInriaSansOnPrimaryContainerBold,
                        ),
                      ],
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
              ),
              SizedBox(height: 14.v),
              Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  right: 12.h,
                ),
                child: BlocSelector<SearchBloc, SearchState,
                    TextEditingController?>(
                  selector: (state) => state.searchController,
                  builder: (context, searchController) {
                    return CustomSearchView(
                      controller: searchController,
                    );
                  },
                ),
              ),
              SizedBox(height: 26.v),
              _buildWorkoChipView(context),
              SizedBox(height: 38.v),
              _buildKPhotosVideosColumn(context),
              SizedBox(height: 11.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(
                    left: 29.h,
                    right: 55.h,
                  ),
                  child: Row(
                    children: [
                      Column(
                        children: [
                          Container(
                            height: 111.v,
                            width: 78.h,
                            decoration: BoxDecoration(
                              color: appTheme.blueGray100,
                              borderRadius: BorderRadius.circular(
                                20.h,
                              ),
                            ),
                          ),
                          SizedBox(height: 14.v),
                          Container(
                            height: 68.v,
                            width: 78.h,
                            decoration: BoxDecoration(
                              color: appTheme.blueGray100,
                              borderRadius: BorderRadius.circular(
                                20.h,
                              ),
                            ),
                          ),
                          SizedBox(height: 7.v),
                          Container(
                            height: 102.v,
                            width: 78.h,
                            decoration: BoxDecoration(
                              color: appTheme.blueGray100,
                              borderRadius: BorderRadius.circular(
                                20.h,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 21.h),
                        child: Column(
                          children: [
                            Container(
                              height: 189.v,
                              width: 78.h,
                              decoration: BoxDecoration(
                                color: appTheme.blueGray100,
                                borderRadius: BorderRadius.circular(
                                  20.h,
                                ),
                              ),
                            ),
                            SizedBox(height: 11.v),
                            Container(
                              height: 41.v,
                              width: 78.h,
                              decoration: BoxDecoration(
                                color: appTheme.blueGray100,
                                borderRadius: BorderRadius.circular(
                                  20.h,
                                ),
                              ),
                            ),
                            SizedBox(height: 11.v),
                            Container(
                              height: 50.v,
                              width: 78.h,
                              decoration: BoxDecoration(
                                color: appTheme.blueGray100,
                                borderRadius: BorderRadius.circular(
                                  20.h,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 21.h),
                        child: Column(
                          children: [
                            Container(
                              height: 102.v,
                              width: 78.h,
                              decoration: BoxDecoration(
                                color: appTheme.blueGray100,
                                borderRadius: BorderRadius.circular(
                                  20.h,
                                ),
                              ),
                            ),
                            SizedBox(height: 9.v),
                            Container(
                              height: 102.v,
                              width: 78.h,
                              decoration: BoxDecoration(
                                color: appTheme.blueGray100,
                                borderRadius: BorderRadius.circular(
                                  20.h,
                                ),
                              ),
                            ),
                            SizedBox(height: 9.v),
                            Container(
                              height: 80.v,
                              width: 78.h,
                              decoration: BoxDecoration(
                                color: appTheme.blueGray100,
                                borderRadius: BorderRadius.circular(
                                  20.h,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 42.v),
              Text(
                "lbl_load_more".tr,
                style: TextStyle(
                  color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                  fontSize: 15.fSize,
                  fontFamily: 'Inria Sans',
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 3.v),
              SizedBox(
                width: 100.h,
                child: Divider(),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 76.v,
      leadingWidth: 68.h,
      leading: AppbarLeadingIconbutton(
        imagePath: ImageConstant.imgGoBack,
        margin: EdgeInsets.only(left: 16.h),
      ),
      actions: [
        AppbarTrailingCircleimage(
          imagePath: ImageConstant.imgProfileIcon,
          margin: EdgeInsets.only(
            left: 25.h,
            right: 25.h,
            bottom: 11.v,
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildWorkoChipView(BuildContext context) {
    return BlocSelector<SearchBloc, SearchState, SearchModel?>(
      selector: (state) => state.searchModelObj,
      builder: (context, searchModelObj) {
        return Wrap(
          runSpacing: 4.v,
          spacing: 4.h,
          children: List<Widget>.generate(
            searchModelObj?.workochipviewItemList.length ?? 0,
            (index) {
              WorkochipviewItemModel model =
                  searchModelObj?.workochipviewItemList[index] ??
                      WorkochipviewItemModel();

              return WorkochipviewItemWidget(
                model,
                onSelectedChipView: (value) {
                  context.read<SearchBloc>().add(
                      UpdateChipViewEvent(index: index, isSelected: value));
                },
              );
            },
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildKPhotosVideosColumn(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 12.h),
      padding: EdgeInsets.symmetric(horizontal: 11.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 8.h),
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "lbl_214k_photos".tr,
                    style: CustomTextStyles.labelLargeInriaSans13,
                  ),
                  TextSpan(
                    text: "msg_24_videos".tr,
                    style: CustomTextStyles.bodyMedium13,
                  ),
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            endIndent: 39.h,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeContainerPage;
      case BottomBarEnum.Search2:
        return "/";
      case BottomBarEnum.Robot2:
        return "/";
      case BottomBarEnum.Profile2:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.homeContainerPage:
        return HomeContainerPage();
      default:
        return DefaultWidget();
    }
  }
}
