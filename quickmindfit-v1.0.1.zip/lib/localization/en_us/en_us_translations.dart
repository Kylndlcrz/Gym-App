final Map<String, String> enUs = {
  // Profile Screen
  "lbl": "|",
  "lbl_0_followers": "0\nFollowers",
  "lbl_0_following": "0\nFollowing",
  "lbl_calories_burnt": "Calories Burnt",
  "lbl_family": "Family",
  "lbl_jarius_rlan": "Jarius Rlan",
  "lbl_jr_fitness": "JR_fitness",
  "lbl_my_profile": "My Profile",
  "lbl_personal_info": "Personal Info",
  "lbl_workouts_total": "Workouts Total",
  "msg_birthdate_ag":
      "Birthdate:\n\n\nAge:\n\n\nGender:\n\n\nAddress:\n\n\nContact No.",
  "msg_name_of_family": "Name of Family\nMember:\n\nRelatinship",
  "msg_rewards_collected": "Rewards\nCollected",

  // Settings Screen
  "lbl2": ">",
  "lbl_about_us": "About Us",
  "lbl_edit_profile": "Edit Profile",
  "lbl_language": "Language",
  "lbl_profile_details": "Profile Details",
  "lbl_settings": "Settings",
  "lbl_sign_out": "Sign Out",

  // Home - Container Screen
  "lbl_cardiovasc": "Cardiovasc",
  "lbl_endurance": "Endurance",
  "lbl_flexibility": "Flexibility",
  "lbl_user_s_name": "User’s name",
  "lbl_welcome_back": "Welcome Back,",
  "msg_discover": "Discover         Find Trainers       My Workout",
  "msg_explore_by_category": "Explore by category",
  "msg_most_popular_workouts": "Most popular workouts",
  "msg_please_choose_a": "Please choose a workout routine.",
  "msg_quick_and_effective": "Quick and effective workouts",
  "msg_you_re_new_here": "You’re new here. Start your day now!",

  // Search Screen
  "lbl_214k_photos": "214k Photos            ",
  "lbl_hello": "Hello,",
  "lbl_load_more": "Load more",
  "lbl_mindfulness": "Mindfulness",
  "lbl_nutrition": "Nutrition",
  "lbl_worko": "Worko",
  "lbl_workout": "Workout",
  "msg_214k_photos": "214k Photos            24 videos            7 Users",
  "msg_24_videos": "24 videos            7 Users",
  "msg_hello_how_can_we": "Hello, How can we assist you today?",
  "msg_how_can_we_assist": "How can we assist you today?",

  // Chatbot Screen
  "lbl_chatbot": "Chatbot",
  "lbl_flexfit": "FlexFIT",
  "lbl_flexfit_chatbot": "FlexFIT Chatbot",
  "msg_welcome_user_how": "Welcome, User. How can I assist you today?",

  // Select Language Screen
  "lbl_arabic": "Arabic",
  "lbl_chinese": "Chinese",
  "lbl_continue": "CONTINUE",
  "lbl_english": "English",
  "lbl_filipino": "Filipino",
  "lbl_japanese": "Japanese",
  "lbl_korean": "Korean",
  "lbl_search": "Search",

  // About Us Screen
  "lbl3": "<    ",
  "lbl_09067720310": "09067720310",
  "lbl_contact_number": "Contact Number                                       ",
  "lbl_contact_us": "Contact Us",
  "lbl_facebook": "Facebook\n",
  "lbl_instagram": "Instagram\n",
  "lbl_qck_mndft": "                           qck_mndft",
  "lbl_quick_mindfit": "                               quick_mindfIT",
  "lbl_quick_mindfit2": "                               Quick MindfIT",
  "lbl_twitter": "Twitter\n",
  "msg_contact_number_09067720310": "Contact Number\n09067720310",
  "msg_customer_support": "Customer Support ",
  "msg_facebook_quick_mindfit": "Facebook\nQuick MindfIT",
  "msg_instagram_quick_mindfit": "Instagram\nquick_mindfIT",
  "msg_social_media_platforms": "Social Media Platforms",
  "msg_twitter_qck_mndft": "Twitter\nqck_mndft",
  "msg_you_can_get_in_touch":
      "You can get in touch through below platforms.\nOur team will reach out to you as soon as \npossible.",

  // Tech Support Screen
  "lbl_e_mail_address2": "E-Mail Address:",
  "lbl_phone_number": "Phone Number:",
  "lbl_your_name": "Your Name:",
  "msg_problem_description_feedback": "Problem Description/Feedback:",

  // Notification Screen
  "lbl_clear_all": "Clear All", "msg_no_notification": "No notification \nyet!",

  // Common String
  "lbl4": "=", "lbl_notifications": "Notifications", "lbl_strength": "Strength",
  "lbl_tech_support": "Tech Support",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
