import 'package:flutter/material.dart';
import 'package:quickmindfit/presentation/profile_screen/profile_screen.dart';
import 'package:quickmindfit/presentation/settings_screen/settings_screen.dart';
import 'package:quickmindfit/presentation/home_container1_screen/home_container1_screen.dart';
import 'package:quickmindfit/presentation/search_screen/search_screen.dart';
import 'package:quickmindfit/presentation/chatbot_screen/chatbot_screen.dart';
import 'package:quickmindfit/presentation/select_language_screen/select_language_screen.dart';
import 'package:quickmindfit/presentation/about_us_screen/about_us_screen.dart';
import 'package:quickmindfit/presentation/tech_support_screen/tech_support_screen.dart';
import 'package:quickmindfit/presentation/notification_screen/notification_screen.dart';
import 'package:quickmindfit/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String profileScreen = '/profile_screen';

  static const String settingsScreen = '/settings_screen';

  static const String homeContainerPage = '/home_container_page';

  static const String homeContainer1Screen = '/home_container1_screen';

  static const String searchScreen = '/search_screen';

  static const String chatbotScreen = '/chatbot_screen';

  static const String selectLanguageScreen = '/select_language_screen';

  static const String aboutUsScreen = '/about_us_screen';

  static const String techSupportScreen = '/tech_support_screen';

  static const String notificationScreen = '/notification_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        profileScreen: ProfileScreen.builder,
        settingsScreen: SettingsScreen.builder,
        homeContainer1Screen: HomeContainer1Screen.builder,
        searchScreen: SearchScreen.builder,
        chatbotScreen: ChatbotScreen.builder,
        selectLanguageScreen: SelectLanguageScreen.builder,
        aboutUsScreen: AboutUsScreen.builder,
        techSupportScreen: TechSupportScreen.builder,
        notificationScreen: NotificationScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: HomeContainer1Screen.builder
      };
}
